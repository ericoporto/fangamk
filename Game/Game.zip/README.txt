in this folder, run:

python -m SimpleHTTPServer

Then open the following URL in Chrome (or any other web browser):

http://0.0.0.0:8000

This solves the bug in Chrome at the moment.


